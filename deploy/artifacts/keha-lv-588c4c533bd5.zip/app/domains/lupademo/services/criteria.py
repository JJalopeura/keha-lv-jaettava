"""Permit criteria CRUD: load, save, version history, rule management.
Depends on domain.py + db_helpers.py only."""

from __future__ import annotations

import copy
import time
from typing import Any

from .core import SPEC_ROOT, application_id_for, artifact_json, event, load_json, save_artifact
from .db_helpers import _dict
from .domain import PERMIT_SCHEMAS


CRITERIA_FILES = {
    "building_residential": "vantaa_building_residential_demo_v1.json",
    "environmental_industrial": "national_environmental_industrial_demo_v1.json",
    "event_public": "vantaa_event_public_demo_v1.json",
}

# City-specific criteria variants per permit type. The default (empty string)
# is the fallback used when no city-specific set matches the inputted
# municipality. Keys are normalized (lowercased, trimmed) municipality names.
CRITERIA_BY_MUNICIPALITY: dict[str, dict[str, str]] = {
    "building_residential": {
        "vantaa": "vantaa_building_residential_demo_v1.json",
        "kerava": "kerava_building_residential_demo_v1.json",
    },
    "event_public": {
        "vantaa": "vantaa_event_public_demo_v1.json",
    },
}


SEVERITY_ORDER = {"recommendation": 0, "minor": 1, "major": 2, "blocking": 3}

# Criteria are a national, permit-type-level definition, not per-hanke state. The
# artifacts below hold the version every hanke reads, so an edit made in one case
# applies to all cases and to hankkeet created later. Case-level artifacts remain as a
# write-through mirror for the admin page and for older stored artifacts.
CRITERIA_STORE = "__criteria_store__"


def _store_get(db: Any, kind: str, name: str) -> dict[str, Any]:
    return artifact_json(db, CRITERIA_STORE, kind, name, {})


def _store_put(db: Any, kind: str, name: str, data: dict[str, Any]) -> None:
    save_artifact(db, CRITERIA_STORE, kind, name, data)


def _criteria_is_edited(criteria: dict[str, Any]) -> bool:
    return bool(str(criteria.get("updated_by") or "").strip()) or "-edited-" in str(criteria.get("version") or "")


def _normalize_municipality(value: Any) -> str:
    return str(value or "").strip().lower()


def list_municipalities(db: Any = None, case_id: str = "") -> list[str]:
    """Return the distinct municipalities that have city-specific criteria,
    in a stable order. Includes cities registered in CRITERIA_BY_MUNICIPALITY
    plus any city-scoped criteria sets already created in the DB (via the
    admin "add city" flow)."""
    seen: dict[str, str] = {}
    for city_map in CRITERIA_BY_MUNICIPALITY.values():
        for city, filename in city_map.items():
            criteria = load_json(SPEC_ROOT / "criteria_sets" / filename, {})
            label = str(criteria.get("municipality") or "").strip() or city.title()
            seen.setdefault(city, label)
    if db is not None and case_id:
        for item in db.list_artifacts(case_id):
            if item.get("type") != "criteria_set":
                continue
            name = str(item.get("name") or "")
            if ":" in name:
                permit_type, city = name.split(":", 1)
                if permit_type not in CRITERIA_BY_MUNICIPALITY:
                    continue
                if city:
                    seen.setdefault(city, city.title())
    return [seen[city] for city in seen]


def create_city_criteria(db: Any, case_id: str, municipality: str, editor: str = "admin") -> dict[str, Any]:
    """Create city-scoped criteria for permit types with registered variants.

    The sets are seeded from the default criteria and the city is registered
    for the admin dropdown. Returns the first created set.
    """
    city = str(municipality or "").strip()
    if not city:
        raise ValueError("municipality_required")
    result: dict[str, Any] = {}
    for permit_type in PERMIT_SCHEMAS:
        if permit_type not in CRITERIA_BY_MUNICIPALITY:
            continue
        name = _criteria_name(permit_type, city)
        existing = artifact_json(db, case_id, "criteria_set", name, {})
        if existing and _normalize_municipality(existing.get("municipality")) == _normalize_municipality(city):
            continue
        criteria = copy.deepcopy(load_criteria(permit_type, city))
        if _normalize_municipality(criteria.get("municipality")) != _normalize_municipality(city):
            criteria["criteria_set_id"] = f"{_normalize_municipality(city)}_{permit_type}_custom"
        criteria["municipality"] = city
        criteria["version"] = f"{city.lower()}-{int(time.time())}"
        criteria["status"] = "active"
        criteria["updated_at"] = time.time()
        criteria["updated_by"] = editor
        save_artifact(db, case_id, "criteria_set", name, criteria)
        _store_put(db, "criteria_set", name, criteria)
        event(db, case_id, "criteria.city.created", "City criteria created", {"permit_type": permit_type, "municipality": city})
        if not result:
            result = criteria
    return result


def _criteria_name(permit_type: str, municipality: Any = None) -> str:
    """Return a city-scoped storage name only for supported permit types."""
    permit_type = application_id_for(permit_type)
    city = _normalize_municipality(municipality) if permit_type in CRITERIA_BY_MUNICIPALITY else ""
    return f"{permit_type}:{city}" if city else permit_type


def load_criteria(permit_type: str, municipality: Any = None) -> dict[str, Any]:
    """Load the criteria file for a permit type, preferring a city-specific
    variant when the inputted municipality matches one. Falls back to the
    default criteria file when no city match is found."""
    permit_type = application_id_for(permit_type)
    filename = CRITERIA_FILES.get(permit_type, CRITERIA_FILES["building_residential"])
    city = _normalize_municipality(municipality)
    if city in {"__national__", "general"} and permit_type == "building_residential":
        filename = "national_building_residential_v1.json"
    if city:
        city_file = CRITERIA_BY_MUNICIPALITY.get(permit_type, {}).get(city)
        if city_file:
            filename = city_file
    return load_json(SPEC_ROOT / "criteria_sets" / filename, {})


def effective_criteria(db: Any, case_id: str, permit_type: str, municipality: Any = None) -> dict[str, Any]:
    """Return the current criteria set for a permit type — the same for every hanke.

    The store holds the one authoritative version; a case never pins its own copy, so
    criteria edited in the admin view apply immediately to every hanke and every later
    check. The bundled JSON is the factory default, used until someone edits.
    """
    permit_type = application_id_for(permit_type)
    name = _criteria_name(permit_type, municipality)
    requested_city = _normalize_municipality(municipality) if permit_type in CRITERIA_BY_MUNICIPALITY else ""
    bundled = load_criteria(permit_type, municipality)
    criteria = _store_get(db, "criteria_set", name)
    if criteria and requested_city and _normalize_municipality(criteria.get("municipality")) != requested_city:
        criteria = {}
    if not criteria:
        if requested_city and _normalize_municipality(bundled.get("municipality")) != requested_city:
            # No city-specific set exists for this municipality: keep the national
            # default rather than storing it under a city name.
            return bundled
        criteria = copy.deepcopy(bundled)
        _store_put(db, "criteria_set", name, criteria)
    elif (
        not _criteria_is_edited(criteria)
        and str(criteria.get("criteria_set_id") or "") == str(bundled.get("criteria_set_id") or "")
        and str(criteria.get("version") or "") != str(bundled.get("version") or "")
    ):
        # A shipped default advanced and nobody has edited the set: take the new default.
        criteria = copy.deepcopy(bundled)
        _store_put(db, "criteria_set", name, criteria)
    if requested_city and _normalize_municipality(criteria.get("municipality")) != requested_city:
        return criteria
    # Mirror to the case so the admin page and any older reader see the same version.
    mirror = artifact_json(db, case_id, "criteria_set", name, {})
    if (
        not mirror
        or str(mirror.get("version") or "") != str(criteria.get("version") or "")
        or str(mirror.get("updated_by") or "") != str(criteria.get("updated_by") or "")
    ):
        save_artifact(db, case_id, "criteria_set", name, criteria)
    return criteria


def _validate_criteria_payload(criteria: Any) -> None:
    """F15/F26: reject non-object payloads and unknown severities with clear errors."""
    if not isinstance(criteria, dict):
        raise ValueError("criteria_payload_must_be_object")
    for rule in criteria.get("rules") or []:
        if not isinstance(rule, dict):
            raise ValueError("criteria_rule_must_be_object")
        severity = str(rule.get("severity") or "major").strip().lower()
        if severity not in SEVERITY_ORDER:
            raise ValueError(f"unknown_severity:{severity}")


def save_criteria_version(db: Any, case_id: str, permit_type: str, criteria: dict[str, Any], editor: str = "admin", municipality: Any = None) -> dict[str, Any]:
    _validate_criteria_payload(criteria)
    permit_type = application_id_for(permit_type)
    name = _criteria_name(permit_type, municipality)
    current = effective_criteria(db, case_id, permit_type, municipality)
    history = artifact_json(db, case_id, "criteria_history", name, {"versions": []})
    history.setdefault("versions", []).append({"ts": time.time(), "editor": editor, "action": "replaced", "criteria": current})
    submitted_version = str(criteria.get("version") or "")
    current_version = str(current.get("version") or "")
    criteria["version"] = (
        f"{current_version or 'criteria'}-edited-{time.time_ns()}"
        if not submitted_version or submitted_version == current_version
        else submitted_version
    )
    criteria["status"] = str(criteria.get("status") or "active")
    criteria["source_files"] = criteria.get("source_files") or criteria.get("sources") or []
    criteria["updated_at"] = time.time()
    criteria["updated_by"] = editor
    save_artifact(db, case_id, "criteria_history", name, history)
    save_artifact(db, case_id, "criteria_set", name, criteria)
    # The store is what every hanke reads: persist the edit there too, with its history.
    store_history = _store_get(db, "criteria_history", name) or {"versions": []}
    store_history.setdefault("versions", []).append({"ts": time.time(), "editor": editor, "action": "replaced", "criteria": current})
    _store_put(db, "criteria_history", name, store_history)
    _store_put(db, "criteria_set", name, criteria)
    event(db, case_id, "criteria.updated", "Criteria set updated", {"permit_type": permit_type, "municipality": _normalize_municipality(municipality), "version": criteria.get("version")})
    event(db, case_id, "criteria.promoted", "Criteria set promoted to every hanke", {"permit_type": permit_type, "municipality": _normalize_municipality(municipality), "version": criteria.get("version")})
    return criteria


def criteria_history(db: Any, case_id: str, permit_type: str, municipality: Any = None) -> dict[str, Any]:
    name = _criteria_name(application_id_for(permit_type), municipality)
    stored = _store_get(db, "criteria_history", name)
    if stored.get("versions"):
        return stored
    return artifact_json(db, case_id, "criteria_history", name, {"versions": []})


def criteria_history_rows(history: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    versions = history.get("versions", []) if isinstance(history, dict) else []
    if not isinstance(versions, list):
        return rows
    for index, item in enumerate(versions):
        criteria = _dict(item).get("criteria", {})
        rows.append(
            {
                "history_index": index,
                "ts": item.get("ts", "") if isinstance(item, dict) else "",
                "editor": item.get("editor", "") if isinstance(item, dict) else "",
                "action": item.get("action", "replaced") if isinstance(item, dict) else "replaced",
                "version": criteria.get("version", "") if isinstance(criteria, dict) else "",
                "status": criteria.get("status", "") if isinstance(criteria, dict) else "",
                "rule_count": len(criteria.get("rules", [])) if isinstance(criteria, dict) and isinstance(criteria.get("rules"), list) else 0,
            }
        )
    return list(reversed(rows))


def rule_titles(criteria: dict[str, Any]) -> dict[str, str]:
    """Map rule id -> short human label.

    Criteria sets carry an optional `title` per rule. Without it the review UI
    falls back to the machine id (`yva_process`) or a truncated regulation
    sentence, both of which read badly in an application review.
    """
    titles: dict[str, str] = {}
    for rule in (criteria or {}).get("rules", []) or []:
        if not isinstance(rule, dict):
            continue
        rule_id = str(rule.get("id") or "").strip()
        title = str(rule.get("title") or "").strip()
        if rule_id and title:
            titles[rule_id] = title
    return titles


def domain_hints_text(criteria: dict[str, Any]) -> str:
    """Permit-type-specific review hints for the AI validators, as bullet text.

    The prompt files are permit-agnostic; without this block a Ympäristölupa
    check is told what matters in a building permit rather than in a YSL
    application. Empty when the criteria set defines no `domain_hints`.
    """
    hints = (criteria or {}).get("domain_hints") or []
    lines = [f"- {str(hint).strip()}" for hint in hints if str(hint or "").strip()]
    return "\n".join(lines)


def criteria_rule_rows(criteria: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    rules = criteria.get("rules", []) if isinstance(criteria, dict) else []
    if not isinstance(rules, list):
        return rows
    for index, rule in enumerate(rules):
        if not isinstance(rule, dict):
            continue
        rows.append(
            {
                "index": index,
                "id": rule.get("id", ""),
                "title": rule.get("title", ""),
                "field_id": rule.get("field_id", ""),
                "attachment_type": rule.get("attachment_type", ""),
                "severity": rule.get("severity", "major"),
                "instruction": rule.get("instruction", ""),
            }
        )
    return rows


def restore_criteria_version(db: Any, case_id: str, permit_type: str, history_index: int, editor: str = "admin", municipality: Any = None) -> dict[str, Any]:
    permit_type = application_id_for(permit_type)
    history = criteria_history(db, case_id, permit_type, municipality)
    versions = history.get("versions", [])
    if not isinstance(versions, list) or history_index < 0 or history_index >= len(versions):
        raise ValueError("criteria_history_index_not_found")
    selected = versions[history_index].get("criteria", {})
    if not isinstance(selected, dict) or not selected:
        raise ValueError("criteria_history_entry_missing_criteria")
    restored = copy.deepcopy(selected)
    restored["status"] = "active"
    restored["restored_from_version"] = selected.get("version", "")
    restored["restored_at"] = time.time()
    restored["version"] = f"{selected.get('version', 'criteria')}-restored-{int(restored['restored_at'])}"
    saved = save_criteria_version(db, case_id, permit_type, restored, editor=editor, municipality=municipality)
    event(db, case_id, "criteria.restored", "Criteria version restored", {"permit_type": permit_type, "municipality": _normalize_municipality(municipality), "history_index": history_index, "version": saved.get("version")})
    return saved


def upsert_criteria_rule(db: Any, case_id: str, permit_type: str, rule: dict[str, Any], editor: str = "admin", municipality: Any = None) -> dict[str, Any]:
    permit_type = application_id_for(permit_type)
    rule_id = str(rule.get("id") or "").strip()
    if not rule_id:
        raise ValueError("criteria_rule_id_required")
    updated = copy.deepcopy(effective_criteria(db, case_id, permit_type, municipality))
    rules = updated.setdefault("rules", [])
    if not isinstance(rules, list):
        rules = []
        updated["rules"] = rules
    rule_severity = str(rule.get("severity") or "major").strip().lower()
    if rule_severity not in SEVERITY_ORDER:
        raise ValueError(f"unknown_severity:{rule_severity}")
    clean_rule = {
        "id": rule_id,
        "severity": rule_severity,
        "instruction": str(rule.get("instruction") or "").strip(),
        "field_id": str(rule.get("field_id") or "").strip(),
        "attachment_type": str(rule.get("attachment_type") or "").strip(),
    }
    replaced = False
    for index, existing in enumerate(rules):
        if isinstance(existing, dict) and existing.get("id") == rule_id:
            merged = {**existing, **clean_rule}
            for key in ("field_id", "attachment_type"):
                if not merged.get(key):
                    merged.pop(key, None)
            rules[index] = merged
            replaced = True
            break
    if not replaced:
        rules.append(clean_rule)
    updated["version"] = f"{str(updated.get('version') or 'criteria')}-rule-{int(time.time())}"
    saved = save_criteria_version(db, case_id, permit_type, updated, editor=editor, municipality=municipality)
    event(db, case_id, "criteria.rule.upserted", "Criteria rule upserted", {"permit_type": permit_type, "municipality": _normalize_municipality(municipality), "rule_id": rule_id, "mode": "updated" if replaced else "added"})
    return saved


def delete_criteria_rule(db: Any, case_id: str, permit_type: str, rule_id: str, editor: str = "admin", municipality: Any = None) -> dict[str, Any]:
    permit_type = application_id_for(permit_type)
    rule_id = str(rule_id or "").strip()
    if not rule_id:
        raise ValueError("criteria_rule_id_required")
    updated = copy.deepcopy(effective_criteria(db, case_id, permit_type, municipality))
    rules = updated.get("rules", [])
    if not isinstance(rules, list):
        rules = []
    next_rules = [rule for rule in rules if not (isinstance(rule, dict) and rule.get("id") == rule_id)]
    if len(next_rules) == len(rules):
        raise ValueError("criteria_rule_not_found")
    updated["rules"] = next_rules
    updated["version"] = f"{str(updated.get('version') or 'criteria')}-delete-{int(time.time())}"
    saved = save_criteria_version(db, case_id, permit_type, updated, editor=editor, municipality=municipality)
    event(db, case_id, "criteria.rule.deleted", "Criteria rule deleted", {"permit_type": permit_type, "municipality": _normalize_municipality(municipality), "rule_id": rule_id})
    return saved
